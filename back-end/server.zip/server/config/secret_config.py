AliAccessKeyID = 'LTAI4GAUSSW89A6pR6Yk5Uee'
AliAccessKeySecret = 'pJWJqQwNXYuvhyjkOwdpW7Fca94kv8'

TxSecretId = 'AKIDwjGEvMfl5B6rR54cFbhX8aPTM3ZvlKNI'
TxSecretKey = "HE2kNr42mFBqGVYbUIt8E6j7JGpFYheQ"

bucket_name = "hexo-blog-1258787237"
